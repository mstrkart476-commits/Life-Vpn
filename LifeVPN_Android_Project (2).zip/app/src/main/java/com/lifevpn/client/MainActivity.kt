package com.lifevpn.client

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.zxing.integration.android.IntentIntegrator
import org.json.JSONArray
import java.net.URL
import java.util.Base64

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val configs = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(), "LifeVPN")
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun addConfig(value: String) {
            runOnUiThread {
                if (value.startsWith("vless://") || value.startsWith("vmess://") || value.startsWith("trojan://")) {
                    configs.add(value.trim())
                    Toast.makeText(this@MainActivity, "کانفیگ ذخیره شد", Toast.LENGTH_SHORT).show()
                    web.evaluateJavascript("showConfigCount(${configs.size})", null)
                } else Toast.makeText(this@MainActivity, "فرمت کانفیگ معتبر نیست", Toast.LENGTH_SHORT).show()
            }
        }
        @JavascriptInterface fun importSubscription(link: String) {
            Thread {
                try {
                    val body = URL(link).readText()
                    val decoded = try { String(Base64.getMimeDecoder().decode(body)) } catch (_: Exception) { body }
                    val found = decoded.lines().filter {
                        it.trim().startsWith("vless://") || it.trim().startsWith("vmess://") || it.trim().startsWith("trojan://")
                    }
                    runOnUiThread {
                        configs.addAll(found.map { it.trim() })
                        web.evaluateJavascript("showConfigCount(${configs.size})", null)
                        Toast.makeText(this@MainActivity, "${found.size} کانفیگ دریافت شد", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this@MainActivity, "دریافت اشتراک ناموفق بود", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
        @JavascriptInterface fun scanQr() {
            runOnUiThread {
                IntentIntegrator(this@MainActivity).setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                    .setPrompt("QR کانفیگ را اسکن کنید").setBeepEnabled(false).initiateScan()
            }
        }
        @JavascriptInterface fun connect() {
            runOnUiThread {
                Toast.makeText(this@MainActivity, "هسته Xray و سرویس VPN هنوز به پروژه اضافه نشده است", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null && result.contents != null) {
            (web as? WebView)?.evaluateJavascript("addScannedConfig(${org.json.JSONObject.quote(result.contents)})", null)
        } else super.onActivityResult(requestCode, resultCode, data)
    }
}
